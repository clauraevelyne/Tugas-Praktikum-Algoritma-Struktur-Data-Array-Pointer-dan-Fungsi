#include <stdio.h>
#include <stdlib.h>

// Fungsi untuk menentukan apakah sebuah kartu adalah angka atau karakter J, Q, K
int isNumeric(char c) {
    return (c >= '0' && c <= '9');
}

// Fungsi untuk menghitung jumlah minimal langkah pertukaran
int minExchangeSteps(int N, char cards[]) {
    int steps = 0;

    // Array untuk menyimpan apakah kartu telah diurutkan
    int sorted[13] = {0};

    // Mengisi array sorted dengan 1 untuk kartu yang sudah diurutkan
    for (int i = 0; i < N; i++) {
        if (isNumeric(cards[i])) {
            sorted[cards[i] - '0'] = 1;
        } else {
            if (cards[i] == 'J') {
                sorted[11] = 1;
            } else if (cards[i] == 'Q') {
                sorted[12] = 1;
            } else if (cards[i] == 'K') {
                sorted[13] = 1;
            }
        }
    }

    // Menghitung jumlah kartu yang belum diurutkan
    for (int i = 1; i <= N; i++) {
        if (!sorted[i]) {
            steps++;
        }
    }

    return steps;
}

int main() {
    int N;
    scanf("%d", &N); // Menerima jumlah kartu

    char *cards = (char *)malloc(N * sizeof(char));
    
    // Menerima nilai kartu
    for (int i = 0; i < N; i++) {
        scanf(" %c", &cards[i]);
    }

    // Menghitung jumlah minimal langkah pertukaran
    int steps = minExchangeSteps(N, cards);

    printf("%d\n", steps);

    free(cards);

    return 0;
}
